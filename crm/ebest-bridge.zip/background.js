'use strict';
const CRM='https://clubaqua.github.io',EBEST='https://ebestm.renaultkoream.com';
const validSender=(sender,origin,path)=>{try{const u=new URL(sender.url);return u.origin===origin&&u.pathname.startsWith(path);}catch{return false;}};
const normalize=v=>String(v||'').replace(/\D/g,'');
chrome.alarms.onAlarm.addListener(async alarm=>{if(alarm.name==='crm-job-expiry'){const {job}=await chrome.storage.session.get('job');if(job&&job.expires<=Date.now())await chrome.storage.session.remove('job');}});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{(async()=>{
if(m?.type==='CRM_PING'&&validSender(sender,CRM,'/crm/'))return {ok:true,version:'1.0.0'};
if(m?.type==='CRM_PREPARE'&&validSender(sender,CRM,'/crm/')){
 const raw=m.payload;if(!raw||typeof raw.body!=='string'||!raw.body.trim()||raw.body.length>2000||!Array.isArray(raw.recipients)||!raw.recipients.length||raw.recipients.length>100)throw Error('문자와 수신자(최대 100명)를 확인하세요.');
 const recipients=raw.recipients.map(r=>({name:String(r.name||'고객').slice(0,50),phone:normalize(r.phone)}));if(recipients.some(r=>!/^01\d{8,9}$/.test(r.phone)))throw Error('올바르지 않은 휴대전화번호가 있습니다.');if(new Set(recipients.map(r=>r.phone)).size!==recipients.length)throw Error('중복 번호를 제거하세요.');
 const old=(await chrome.storage.session.get('job')).job;if(old&&old.expires>Date.now()&&['queued','login','filling'].includes(old.status))throw Error('이전에 전달한 건이 대기 중입니다. 이베스트 화면을 확인하거나 연결 대기를 취소하세요.');
 const tabs=await chrome.tabs.query({url:EBEST+'/v2/*'});let tab=tabs.find(t=>t.url===EBEST+'/v2/main')||tabs[0];if(!tab)tab=await chrome.tabs.create({url:EBEST+'/v2/main',active:true});
 const job={id:crypto.randomUUID(),body:raw.body.trim(),recipients,expires:Date.now()+10*60*1000,tabId:tab.id,sourceTabId:sender.tab.id,status:'queued'};await chrome.storage.session.set({job});await chrome.alarms.create('crm-job-expiry',{when:job.expires});await chrome.tabs.update(tab.id,{active:true});await chrome.tabs.sendMessage(tab.id,{type:'EBEST_RESUME'}).catch(()=>{});return {ok:true,jobId:job.id,status:'queued'};
}
if(m?.type==='CRM_STATUS'&&validSender(sender,CRM,'/crm/')){const job=(await chrome.storage.session.get('job')).job;return {ok:true,status:job?.sourceTabId===sender.tab.id?(job.expires>Date.now()?job.status:'expired'):'none',message:job?.sourceTabId===sender.tab.id?job.message||'':''};}
if(m?.type==='CRM_CANCEL'&&validSender(sender,CRM,'/crm/')){const job=(await chrome.storage.session.get('job')).job;if(job?.sourceTabId===sender.tab.id)await chrome.storage.session.remove('job');return {ok:true};}
if(m?.type==='EBEST_GET'&&validSender(sender,EBEST,'/v2/')){const job=(await chrome.storage.session.get('job')).job;if(!job||job.tabId!==sender.tab.id||job.expires<Date.now()||!['queued','login'].includes(job.status))return {ok:true,job:null};return {ok:true,job};}
if(m?.type==='EBEST_CHECK'&&validSender(sender,EBEST,'/v2/')){const job=(await chrome.storage.session.get('job')).job;return {ok:true,active:job?.id===m.jobId&&job.tabId===sender.tab.id&&job.expires>Date.now()&&job.status==='filling'};}
if(m?.type==='EBEST_UPDATE'&&validSender(sender,EBEST,'/v2/')){const job=(await chrome.storage.session.get('job')).job;if(!job||job.id!==m.jobId||job.tabId!==sender.tab.id||job.expires<=Date.now())return {ok:false};if(!['login','filling','ready','error'].includes(m.status))return {ok:false};job.status=m.status;job.message=String(m.message||'').slice(0,300);if(['ready','error'].includes(m.status)){delete job.body;delete job.recipients;}await chrome.storage.session.set({job});return {ok:true};}
return {ok:false};
})().then(reply).catch(e=>reply({ok:false,error:e.message}));return true;});
