'use strict';
const CRM='https://clubaqua.github.io',EBEST='https://ebestm.renaultkoream.com';
const validSender=(sender,origin,path)=>{try{const u=new URL(sender.url);return u.origin===origin&&u.pathname.startsWith(path);}catch{return false;}};
const normalize=v=>String(v||'').replace(/\D/g,'');
chrome.alarms.onAlarm.addListener(async alarm=>{if(alarm.name==='crm-job-expiry'){const {job}=await chrome.storage.session.get('job');if(job&&job.expires<=Date.now())await chrome.storage.session.remove('job');}});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{(async()=>{
if(['CRM2_ACCOUNT','CRM2_SEND','CRM2_LAST','CRM2_ACK'].includes(m?.type)&&validSender(sender,CRM,'/crm/'))return directSms(m,sender);
if(m?.type==='CRM_PING'&&validSender(sender,CRM,'/crm/'))return {ok:true,version:'2.1.0'};
if(m?.type==='CRM_PREPARE'&&validSender(sender,CRM,'/crm/')){
 const raw=m.payload;if(!raw||typeof raw.body!=='string'||!raw.body.trim()||raw.body.length>2000||!Array.isArray(raw.recipients)||!raw.recipients.length||raw.recipients.length>100)throw Error('문자와 수신자(최대 100명)를 확인하세요.');
 const recipients=raw.recipients.map(r=>({name:String(r.name||'고객').slice(0,50),phone:normalize(r.phone)}));if(recipients.some(r=>!/^01\d{8,9}$/.test(r.phone)))throw Error('올바르지 않은 휴대전화번호가 있습니다.');if(new Set(recipients.map(r=>r.phone)).size!==recipients.length)throw Error('중복 번호를 제거하세요.');
 const old=(await chrome.storage.session.get('job')).job;if(old&&old.expires>Date.now()&&['queued','login','filling'].includes(old.status))throw Error('이전에 전달한 건이 대기 중입니다. 이베스트 화면을 확인하거나 연결 대기를 취소하세요.');
 const tabs=await chrome.tabs.query({url:EBEST+'/v2/*'});let tab=tabs.find(t=>t.url===EBEST+'/v2/main')||tabs[0];if(!tab)tab=await chrome.tabs.create({url:EBEST+'/v2/main',active:true});
 const job={id:crypto.randomUUID(),body:raw.body.trim(),recipients,expires:Date.now()+10*60*1000,tabId:tab.id,sourceTabId:sender.tab.id,status:'queued'};await chrome.storage.session.set({job});await chrome.alarms.create('crm-job-expiry',{when:job.expires});await chrome.tabs.update(tab.id,{active:true});await chrome.tabs.sendMessage(tab.id,{type:'EBEST_RESUME'}).catch(()=>{});return {ok:true,jobId:job.id,status:'queued'};
}
if(m?.type==='CRM_STATUS'&&validSender(sender,CRM,'/crm/')){const job=(await chrome.storage.session.get('job')).job;return {ok:true,status:job?.sourceTabId===sender.tab.id?(job.expires>Date.now()?job.status:'expired'):'none',message:job?.sourceTabId===sender.tab.id?job.message||'':''};}
if(m?.type==='CRM_CANCEL'&&validSender(sender,CRM,'/crm/')){const job=(await chrome.storage.session.get('job')).job;if(job?.sourceTabId===sender.tab.id)await chrome.storage.session.remove('job');return {ok:true};}
if(m?.type==='EBEST_GET'&&validSender(sender,EBEST,'/v2/')){const job=(await chrome.storage.session.get('job')).job;if(!job||job.tabId!==sender.tab.id||job.expires<Date.now()||!['queued','login'].includes(job.status))return {ok:true,job:null};return {ok:true,job};}
if(m?.type==='EBEST_CHECK'&&validSender(sender,EBEST,'/v2/')){const job=(await chrome.storage.session.get('job')).job;return {ok:true,active:job?.id===m.jobId&&job.tabId===sender.tab.id&&job.expires>Date.now()&&job.status==='filling'};}
if(m?.type==='EBEST_UPDATE'&&validSender(sender,EBEST,'/v2/')){const job=(await chrome.storage.session.get('job')).job;if(!job||job.id!==m.jobId||job.tabId!==sender.tab.id||job.expires<=Date.now())return {ok:false};if(!['login','filling','ready','error'].includes(m.status))return {ok:false};job.status=m.status;job.message=String(m.message||'').slice(0,300);if(['ready','error'].includes(m.status)){delete job.body;delete job.recipients;}await chrome.storage.session.set({job});return {ok:true};}
return {ok:false};
})().then(reply).catch(e=>reply({ok:false,error:e.message}));return true;});

// SMS2 keeps account authentication inside the user's eBEST tab; no cookie/password access.
let directBusy=false;
chrome.alarms.onAlarm.addListener(async alarm=>{if(alarm.name==='crm2-expiry'){const {sms2Attempt}=await chrome.storage.session.get('sms2Attempt');if(sms2Attempt?.expires<=Date.now())await chrome.storage.session.remove('sms2Attempt');}});
async function directSms(m,sender){
 if(m.type==='CRM2_ACK'){const {sms2Attempt:a}=await chrome.storage.session.get('sms2Attempt');if(a?.status==='sending'&&a.expires>Date.now())return {ok:false,error:'발송 요청이 아직 처리 중입니다. 잠시 후 결과를 확인하세요.'};if(a?.status==='unknown'){a.status='acknowledged';a.message='사용자가 이베스트 발송결과 확인을 완료했습니다.';await chrome.storage.session.set({sms2Attempt:a});}return {ok:true};}
 if(m.type==='CRM2_LAST'){const {sms2Attempt:a}=await chrome.storage.session.get('sms2Attempt');return {ok:true,attempt:a?.sourceTabId===sender.tab.id&&a.expires>Date.now()?{status:a.status,message:a.message,time:a.time}:null};}
 const tabs=await chrome.tabs.query({url:EBEST+'/v2/*'}),tab=tabs.find(t=>t.url===EBEST+'/v2/main')||tabs.find(t=>!t.url.includes('/auth/')&&!t.url.includes('/error/'));
 if(!tab)throw Error('같은 브라우저에서 이베스트에 먼저 로그인하세요. 로그인 탭은 열어둔 채 CRM에서 발송할 수 있습니다.');
 if(m.type==='CRM2_ACCOUNT'){try{return await chrome.tabs.sendMessage(tab.id,{type:'SMS2_ACCOUNT'});}catch{throw Error('연결 프로그램 2.1 설치 후 이베스트와 CRM 탭을 모두 새로고침하세요.');}}
 const p=m.payload;if(!p||typeof p.operationId!=='string'||!/^[a-zA-Z0-9-]{16,80}$/.test(p.operationId)||p.confirmed!==true||!Array.isArray(p.recipients)||p.recipients.length<1||p.recipients.length>100||typeof p.body!=='string'||p.body.length>2000||!p.body.trim()||!Number.isFinite(p.maxCost)||p.maxCost<=0||!/^01[016789]\d{7,8}$/.test(p.expectedSender))throw Error('발송 확인 값이 올바르지 않습니다.');
 const {sms2Attempt:old}=await chrome.storage.session.get('sms2Attempt');if(directBusy||old?.status==='sending'&&old.expires>Date.now())throw Error('이전 발송 결과를 확인 중입니다. 이베스트 발송결과를 먼저 확인하세요.');if(old?.status==='unknown'&&old.expires>Date.now())return {ok:false,uncertain:true,error:'이전 요청의 발송 결과가 불명확합니다. 이베스트 발송결과 확인 후 확인 완료를 눌러주세요.'};if(old?.id===p.operationId)throw Error('이미 처리한 발송 요청입니다. 자동 재전송하지 않습니다.');
 directBusy=true;const a={id:p.operationId,sourceTabId:sender.tab.id,status:'sending',time:Date.now(),expires:Date.now()+30*60*1000,message:'요청 처리 중 · 재전송 전 발송결과를 확인하세요.'};
 try{await chrome.storage.session.set({sms2Attempt:a});await chrome.alarms.create('crm2-expiry',{when:a.expires});let result;try{result=await chrome.tabs.sendMessage(tab.id,{type:'SMS2_SEND',payload:p});}catch{result={ok:false,uncertain:true,error:'연결이 끊겨 결과를 확인하지 못했습니다. 재전송 전에 이베스트 발송결과를 확인하세요.'};}if(!result)result={ok:false,uncertain:true,error:'응답이 없어 결과를 확인하지 못했습니다. 이베스트 발송결과를 확인하세요.'};a.status=result.accepted?'accepted':result.uncertain?'unknown':'blocked';a.message=result.message||result.error;await chrome.storage.session.set({sms2Attempt:a});return result;}finally{directBusy=false;}
}

